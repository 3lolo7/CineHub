// ============================================================
// CONFIG & DATA
// ============================================================
const API = 'http://localhost/cinehub-backend/api';

// ============================================================
// STATE
// ============================================================
let currentUser = JSON.parse(localStorage.getItem('cinehub_user') || 'null');
let currentMovieId = null;
let favorites = JSON.parse(localStorage.getItem('cinehub_favorites') || '[]');

// Movie Filters State
let activeMovieGenre = '';
let activeMovieRating = 0;
let activeMovieYears = []; // ✅ FIX 1: كان ['2020-2024'] وبيفلتر تلقائياً

// TV Shows Filters State
let activeTVGenre = '';
let activeTVRating = 0;
let activeTVYears = []; // ✅ FIX 1: كان ['2020-2024'] وبيفلتر تلقائياً

// Cache for movies and TV shows from API
let cachedMovies = [];
let cachedTVShows = [];

// ============================================================
// HELPER FUNCTIONS
// ============================================================
function setHomeDate() {
    const now = new Date();
    const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const el = document.getElementById('home-date');
    if (el) el.textContent = now.toLocaleDateString('en-US', opts);
}

function saveFavorites() {
    localStorage.setItem('cinehub_favorites', JSON.stringify(favorites));
}

function isFavorite(movieId) {
    return favorites.includes(movieId);
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    setTimeout(() => toast.classList.remove('show'), 3000);
}

function toggleFavorite(movieId) {
    // ✅ FIX 2: لو مش logged in، روحه لصفحة signin
    if (!currentUser) {
        showToast('⚠️ Please sign in to add to your list', 'error');
        setTimeout(() => go('signin'), 800);
        return;
    }

    const index = favorites.indexOf(movieId);
    if (index === -1) {
        favorites.push(movieId);
        showToast('❤️ Added to My List', 'success');
    } else {
        favorites.splice(index, 1);
        showToast('🗑️ Removed from My List', 'info');
    }
    saveFavorites();

    // Update heart icon on the card if it exists
    const card = document.querySelector(`.poster-card[data-movie-id="${movieId}"]`);
    if (card) {
        const heartIcon = card.querySelector('.fav-icon i');
        if (heartIcon) {
            if (isFavorite(movieId)) {
                heartIcon.className = 'fas fa-heart';
                heartIcon.style.color = '#e31c24';
            } else {
                heartIcon.className = 'far fa-heart';
                heartIcon.style.color = '';
            }
        }
    }

    // Refresh My List page if it's active
    const myListPage = document.getElementById('page-mylist');
    if (myListPage && myListPage.classList.contains('active')) {
        loadMyList();
    }

    // Update profile favorites
    const profilePage = document.getElementById('page-profile');
    if (profilePage && profilePage.classList.contains('active')) {
        loadProfile();
    }
}

function updateNavAvatar() {
    const av = document.getElementById('nav-avatar');
    if (currentUser && av) {
        av.innerHTML = `<i class="fas fa-user"></i>`;
        av.style.display = 'flex';
    } else if (av) {
        av.style.display = 'none';
    }
}

function fixImageError(img) {
    img.addEventListener('error', function () {
        this.src = 'https://picsum.photos/seed/' + Math.random() + '/300/450';
    });
}

const STAR_SVG = `<i class="fas fa-star" style="color:var(--gold);font-size:10px;margin-right:2px"></i>`;

function buildCard(m, width = 'auto') {
    const isFav = isFavorite(m.id);
    return `
  <div class="poster-card" style="width:${width}" data-movie-id="${m.id}" data-type="movie">
    <img src="${m.poster}" alt="${m.title}" loading="lazy" class="movie-poster">
    <div class="p-overlay"></div>
    <div class="rating-badge">${STAR_SVG}${m.rating}</div>
    <div class="p-cat">${m.category}</div>
    <div class="p-title">${m.title}</div>
    <div class="overlay-icons">
      <div class="oi-btn play-icon" title="Play"><i class="fas fa-play"></i></div>
      <div class="oi-btn secondary fav-icon" title="${isFav ? 'Remove from My List' : 'Add to My List'}">
        <i class="${isFav ? 'fas fa-heart' : 'far fa-heart'}" style="${isFav ? 'color:#e31c24' : ''}"></i>
      </div>
    </div>
  </div>`;
}

function buildTVCard(show, width = 'auto') {
    const isFav = isFavorite(show.id);
    return `
  <div class="poster-card" style="width:${width}" data-movie-id="${show.id}" data-type="tv">
    <img src="${show.poster}" alt="${show.title}" loading="lazy" class="movie-poster">
    <div class="p-overlay"></div>
    <div class="rating-badge">${STAR_SVG}${show.rating}</div>
    <div class="p-cat">${show.category} • ${show.seasons} Seasons</div>
    <div class="p-title">${show.title}</div>
    <div class="overlay-icons">
      <div class="oi-btn play-icon" title="Play"><i class="fas fa-play"></i></div>
      <div class="oi-btn secondary fav-icon" title="${isFav ? 'Remove from My List' : 'Add to My List'}">
        <i class="${isFav ? 'fas fa-heart' : 'far fa-heart'}" style="${isFav ? 'color:#e31c24' : ''}"></i>
      </div>
    </div>
  </div>`;
}

function buildLandCard(m, width = '300px', prog = 0) {
    return `
  <div class="land-card" style="width:${width}" data-movie-id="${m.id}" data-type="movie">
    <div class="l-img">
      <img src="${m.poster}" alt="${m.title}" loading="lazy" class="land-img">
      ${prog > 0 ? `<div class="progress-bar"><div class="progress-fill" style="width:${prog}%"></div></div>` : ''}
    </div>
    <div class="l-info">
      <div class="l-title">${m.title}</div>
      <div class="l-sub">${m.category}</div>
    </div>
  </div>`;
}

// ============================================================
// API FUNCTIONS
// ============================================================
async function fetchMoviesFromAPI(filters = {}) {
    try {
        let url = `${API}/movies.php?`;
        if (filters.genre) url += `genre=${encodeURIComponent(filters.genre)}&`;
        if (filters.rating) url += `rating=${filters.rating}&`;
        if (filters.year) url += `year=${filters.year}&`;
        if (filters.search) url += `search=${encodeURIComponent(filters.search)}&`;

        const response = await fetch(url);
        const data = await response.json();
        if (data.status === 'success') {
            return data.data;
        }
    } catch (error) {
        console.error('Error fetching movies:', error);
    }
    return [];
}

async function fetchTVShowsFromAPI(filters = {}) {
    try {
        let url = `${API}/tvshows.php?`;
        if (filters.genre) url += `genre=${encodeURIComponent(filters.genre)}&`;
        if (filters.rating) url += `rating=${filters.rating}&`;
        if (filters.year) url += `year=${filters.year}&`;
        if (filters.search) url += `search=${encodeURIComponent(filters.search)}&`;

        const response = await fetch(url);
        const data = await response.json();

        if (data.status === 'success') {
            return data.data;
        }
    } catch (error) {
        console.error('Error fetching TV shows:', error);
    }
    return [];
}

// ============================================================
// UI UPDATE BASED ON AUTH STATE
// ============================================================
function updateAuthUI() {
    const authButtons = document.getElementById('auth-buttons');
    const navSignoutBtn = document.getElementById('nav-signout-btn');
    const myListNavLink = document.getElementById('mylist-nav-link');
    const navAvatar = document.getElementById('nav-avatar');
    const signoutItem = document.getElementById('signout-item');

    if (currentUser) {
        if (authButtons) authButtons.style.display = 'none';
        if (navSignoutBtn) navSignoutBtn.style.display = 'flex';
        if (myListNavLink) myListNavLink.style.display = 'block';
        if (navAvatar) navAvatar.style.display = 'flex';
        if (signoutItem) signoutItem.style.display = 'flex';
    } else {
        if (authButtons) authButtons.style.display = 'flex';
        if (navSignoutBtn) navSignoutBtn.style.display = 'none';
        if (myListNavLink) myListNavLink.style.display = 'none';
        if (navAvatar) navAvatar.style.display = 'none';
        if (signoutItem) signoutItem.style.display = 'none';
    }
    updateNavAvatar();
}

// ============================================================
// ROUTER
// ============================================================
function go(page) {
    if (!page) page = 'home';
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById('page-' + page);
    if (!target) { go('home'); return; }
    target.classList.add('active');

    const mainNav = document.getElementById('main-nav');
    mainNav.style.display = 'flex';

    document.querySelectorAll('.nav-link').forEach(l => {
        l.classList.remove('active');
        if (l.dataset.page === page) l.classList.add('active');
    });

    window.scrollTo(0, 0);
    history.pushState(null, '', '#' + page);

    if (page === 'home') { setHomeDate(); loadHomeMovies(); }

    if (page === 'movies') {
        // ✅ شيل الـ check من كل checkboxes السنة عشان متفلترش تلقائياً
        document.querySelectorAll('#page-movies .year-check').forEach(cb => cb.checked = false);
        activeMovieYears = [];
        applyMovieFilters();
    }

    if (page === 'tvshows') {
        // ✅ نفس الكلام للمسلسلات
        document.querySelectorAll('#page-tvshows .tv-year-check').forEach(cb => cb.checked = false);
        activeTVYears = [];
        applyTVFilters();
    }
    if (page === 'mylist') loadMyList();
    if (page === 'profile') loadProfile();

    // ✅ مسح الـ inputs لما بيروح لصفحة signin أو register
    if (page === 'signin') {
        const emailEl = document.getElementById('signin-email');
        const passEl = document.getElementById('signin-pass');
        if (emailEl) emailEl.value = '';
        if (passEl) passEl.value = '';
        // إرجاع الباسورد لـ hidden لو كان مكشوف
        if (passEl) passEl.type = 'password';
        const eyeBtn = document.querySelector('.toggle-password[data-target="signin-pass"]');
        if (eyeBtn) eyeBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    }

    if (page === 'register') {
        ['reg-name', 'reg-email', 'reg-pass', 'reg-confirm'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
            if (el && el.type === 'text') el.type = 'password';
        });
        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
        });
    }
    updateAuthUI();
    updateNavAvatar();
}

// ============================================================
// HOME
// ============================================================
async function loadHomeMovies() {
    setHomeDate();

    const movies = await fetchMoviesFromAPI();

    if (movies.length > 0) {
        cachedMovies = movies;
        document.getElementById('home-trending').innerHTML = movies.slice(0, 8).map(m => buildCard(m, '175px')).join('');
        document.getElementById('home-recent').innerHTML = movies.slice(0, 4).map((m, i) => buildLandCard(m, '300px', [35, 60, 15, 0][i] || 0)).join('');
        document.getElementById('home-recommended').innerHTML = movies.slice(0, 7).map(m => buildCard(m, '155px')).join('');
    } else {
        document.getElementById('home-trending').innerHTML = '<div class="empty-state"><i class="fas fa-film"></i><h3>No movies found</h3></div>';
        document.getElementById('home-recent').innerHTML = '<div class="empty-state"><i class="fas fa-film"></i><h3>No movies found</h3></div>';
        document.getElementById('home-recommended').innerHTML = '<div class="empty-state"><i class="fas fa-film"></i><h3>No movies found</h3></div>';
    }

    document.querySelectorAll('#home-trending img, #home-recent img, #home-recommended img').forEach(fixImageError);
}

// ============================================================
// MOVIES WITH FULL FILTERS
// ============================================================
function filterMoviesByGenre(genre) {
    activeMovieGenre = genre;
    applyMovieFilters();
}

function filterMoviesByRating(rating) {
    activeMovieRating = rating;
    applyMovieFilters();
}

function filterMoviesByYear() {
    activeMovieYears = [];
    document.querySelectorAll('#page-movies .year-check:checked').forEach(cb => {
        activeMovieYears.push(cb.value);
    });
    applyMovieFilters();
}

async function applyMovieFilters() {
    const grid = document.getElementById('movies-grid');
    if (!grid) return;

    grid.innerHTML = '<div class="spinner-wrapper"><div class="spinner"></div></div>';

    const filters = {};
    if (activeMovieGenre) filters.genre = activeMovieGenre;
    if (activeMovieRating > 0) filters.rating = activeMovieRating;
    if (activeMovieYears.length > 0) filters.year = activeMovieYears[0];

    const movies = await fetchMoviesFromAPI(filters);

    if (movies.length > 0) {
        cachedMovies = movies;
        grid.innerHTML = movies.map(m => buildCard(m, 'auto')).join('');
    } else {
        grid.innerHTML = '<div class="empty-state"><i class="fas fa-film"></i><h3>No movies found</h3><p>Try changing your filters</p></div>';
    }

    document.querySelectorAll('#movies-grid img').forEach(fixImageError);
}

// ============================================================
// TV SHOWS WITH FULL FILTERS
// ============================================================
function filterTVShowsByGenre(genre) {
    activeTVGenre = genre;
    applyTVFilters();
}

function filterTVShowsByRating(rating) {
    activeTVRating = rating;
    applyTVFilters();
}

function filterTVShowsByYear() {
    activeTVYears = [];
    document.querySelectorAll('#page-tvshows .tv-year-check:checked').forEach(cb => {
        activeTVYears.push(cb.value);
    });
    applyTVFilters();
}

async function applyTVFilters() {
    const grid = document.getElementById('tvshows-grid');
    if (!grid) return;

    grid.innerHTML = '<div class="spinner-wrapper"><div class="spinner"></div></div>';

    const filters = {};
    if (activeTVGenre) filters.genre = activeTVGenre;
    if (activeTVRating > 0) filters.rating = activeTVRating;
    if (activeTVYears.length > 0) filters.year = activeTVYears[0];

    const tvshows = await fetchTVShowsFromAPI(filters);

    if (tvshows.length > 0) {
        cachedTVShows = tvshows;
        grid.innerHTML = tvshows.map(show => buildTVCard(show, 'auto')).join('');
    } else {
        grid.innerHTML = '<div class="empty-state"><i class="fas fa-tv"></i><h3>No TV shows found</h3><p>Try changing your filters</p></div>';
    }

    document.querySelectorAll('#tvshows-grid img').forEach(fixImageError);
}

// ============================================================
// SEARCH
// ============================================================
let movieSearchTimer;
let tvSearchTimer;

async function handleMovieSearch(e) {
    const q = e.target.value.trim().toLowerCase();
    clearTimeout(movieSearchTimer);

    if (!q) {
        applyMovieFilters();
        return;
    }

    movieSearchTimer = setTimeout(async () => {
        const grid = document.getElementById('movies-grid');
        if (grid) {
            grid.innerHTML = '<div class="spinner-wrapper"><div class="spinner"></div></div>';
            const results = await fetchMoviesFromAPI({ search: q });
            if (results.length > 0) {
                grid.innerHTML = results.map(m => buildCard(m, 'auto')).join('');
            } else {
                grid.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><h3>No results found</h3><p>Try searching for something else</p></div>';
            }
            document.querySelectorAll('#movies-grid img').forEach(fixImageError);
        }
    }, 400);
}

async function handleTVSearch(e) {
    const q = e.target.value.trim().toLowerCase();
    clearTimeout(tvSearchTimer);

    if (!q) {
        applyTVFilters();
        return;
    }

    tvSearchTimer = setTimeout(async () => {
        const grid = document.getElementById('tvshows-grid');
        if (grid) {
            grid.innerHTML = '<div class="spinner-wrapper"><div class="spinner"></div></div>';
            const results = await fetchTVShowsFromAPI({ search: q });
            if (results.length > 0) {
                grid.innerHTML = results.map(show => buildTVCard(show, 'auto')).join('');
            } else {
                grid.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><h3>No results found</h3><p>Try searching for something else</p></div>';
            }
            document.querySelectorAll('#tvshows-grid img').forEach(fixImageError);
        }
    }, 400);
}

// ============================================================
// DETAIL
// ============================================================
function openDetail(id, type = 'movie') {
    currentMovieId = id;
    go('detail');

    let item;

    if (type === 'tv' || (typeof id === 'string' && id.startsWith('s'))) {
        item = cachedTVShows.find(show => show.id === id);
        if (!item && cachedTVShows.length === 0) {
            fetchTVShowsFromAPI().then(shows => {
                cachedTVShows = shows;
                item = shows.find(show => show.id === id);
                if (item) renderDetail(item, true);
            });
            return;
        }
        renderDetail(item, true);
    } else {
        item = cachedMovies.find(m => m.id === id);
        if (!item && cachedMovies.length === 0) {
            fetchMoviesFromAPI().then(movies => {
                cachedMovies = movies;
                item = movies.find(m => m.id === id);
                if (item) renderDetail(item, false);
            });
            return;
        }
        renderDetail(item, false);
    }
}

function renderDetail(item, isTV = false) {
    if (!item) return;

    const heroImg = document.getElementById('detail-hero-img');
    const sidebarPoster = document.getElementById('detail-sidebar-poster');
    if (heroImg) heroImg.src = item.backdrop || item.poster;
    if (sidebarPoster) sidebarPoster.src = item.poster;

    document.getElementById('detail-title').textContent = item.title;
    document.getElementById('detail-rating').textContent = `${item.rating}/10`;
    document.getElementById('detail-rating2').textContent = `⭐ ${item.rating}/10`;
    document.getElementById('detail-genre-tag').textContent = item.category;
    document.getElementById('detail-genre-badge').textContent = item.category;
    document.getElementById('detail-year').textContent = item.year;

    if (isTV && item.seasons) {
        document.getElementById('detail-director').innerHTML = `${item.seasons} Seasons • ${item.episodes} Episodes`;
    } else {
        document.getElementById('detail-director').textContent = item.director || 'Unknown';
    }

    document.getElementById('detail-desc').textContent = item.description || item.desc || 'A cinematic masterpiece.';

    // ✅ FIX 3: جلب الممثلين من API (JSON)
    let castData = [];
    if (item.cast) {
        // لو الـ cast كان string, نحوله لـ array
        if (typeof item.cast === 'string') {
            try {
                castData = JSON.parse(item.cast);
            } catch(e) {
                console.error('Error parsing cast JSON:', e);
                castData = [];
            }
        } else if (Array.isArray(item.cast)) {
            castData = item.cast;
        }
    }

    // لو مفيش ممثلين, نستخدم placeholder
    if (castData.length === 0) {
        castData = [
            { name: 'Information not available', role: 'Cast data coming soon' }
        ];
    }

    document.getElementById('detail-cast').innerHTML = castData.map((c, i) => `
    <div class="cast-item">
      <div class="cast-avatar" style="background:hsl(${i * 60},40%,20%)">
        <i class="fas fa-user" style="font-size: 20px; color: rgba(255,255,255,0.5);"></i>
      </div>
      <div class="cast-info">
        <div class="cast-name">${c.name || 'Unknown'}</div>
        <div class="cast-role">as ${c.role || 'Character'}</div>
      </div>
    </div>`).join('');

    let similar;
    if (isTV) {
        similar = cachedTVShows.filter(x => x.category === item.category && x.id !== item.id).slice(0, 6);
    } else {
        similar = cachedMovies.filter(x => x.category === item.category && x.id !== item.id).slice(0, 6);
    }

    document.getElementById('detail-more').innerHTML = similar.map(x => `
    <div class="poster-card" data-movie-id="${x.id}" data-type="${isTV ? 'tv' : 'movie'}">
      <img src="${x.poster}" alt="${x.title}" loading="lazy" class="movie-poster">
      <div class="p-overlay"></div>
      <div class="rating-badge">${STAR_SVG}${x.rating}</div>
      <div class="p-title">${x.title}</div>
    </div>`).join('');
}

// ============================================================
// MY LIST
// ============================================================
async function loadMyList() {
    const grid = document.getElementById('mylist-grid');

    const allMovies = await fetchMoviesFromAPI();
    const favMovies = favorites.map(id => allMovies.find(m => m.id === id)).filter(Boolean);

    const countSpan = document.getElementById('mylist-count');
    if (countSpan) countSpan.textContent = `${favMovies.length} TITLES`;

    grid.innerHTML = favMovies.length
        ? favMovies.map(m => buildCard(m, 'auto')).join('')
        : '<div class="empty-state"><i class="far fa-heart"></i><h3>Your list is empty</h3><p>Browse movies and click the heart icon to add them here</p></div>';

    document.querySelectorAll('#mylist-grid img').forEach(fixImageError);
}

// ============================================================
// PROFILE
// ============================================================
async function loadProfile() {
    if (!currentUser) { go('signin'); return; }
    document.getElementById('profile-name').textContent = currentUser.name || 'User';
    document.getElementById('profile-email').textContent = currentUser.email || 'user@example.com';
    document.getElementById('profile-avatar-text').innerHTML = '<i class="fas fa-user fa-2x"></i>';
    document.getElementById('profile-since').textContent = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' });

    const allMovies = await fetchMoviesFromAPI();
    const favMovies = favorites.map(id => allMovies.find(m => m.id === id)).filter(Boolean);

    document.getElementById('profile-watchlist-count').textContent = favMovies.length;
    document.getElementById('profile-watched').textContent = Math.max(favMovies.length * 2, 8);

    const favContainer = document.getElementById('profile-favorites');
    if (favContainer) {
        favContainer.innerHTML = favMovies.slice(0, 5).map(m => `
      <div class="poster-card" style="width:150px" data-movie-id="${m.id}" data-type="movie">
        <img src="${m.poster}" alt="${m.title}" loading="lazy" class="movie-poster">
        <div class="p-overlay"></div>
        <div class="rating-badge">${STAR_SVG}${m.rating}</div>
        <div class="p-title">${m.title}</div>
      </div>`).join('') || '<p style="color:var(--gray);padding:20px">No favorites yet — browse movies! 🎬</p>';
    }
}

// ============================================================
// LOGIN
// ============================================================
async function doLogin() {
    const email = document.getElementById('signin-email').value.trim();
    const pass = document.getElementById('signin-pass').value;
    const btn = document.getElementById('signin-btn');
    if (!email || !pass) { alert('Email and password are required'); return; }
    if (btn) { btn.disabled = true; btn.innerHTML = '<div class="spinner"></div> Signing in...'; }

    try {
        const response = await fetch(`${API}/login.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password: pass })
        });
        const data = await response.json();
        if (data.status === 'success') {
            currentUser = data.data;
            localStorage.setItem('cinehub_user', JSON.stringify(currentUser));
            updateAuthUI();
            go('home');
            showToast(`Welcome back, ${currentUser.name}!`, 'success');
        } else {
            alert(data.message);
        }
    } catch (error) {
        // Fallback for demo
        currentUser = { id: 1, name: email.split('@')[0], email: email };
        localStorage.setItem('cinehub_user', JSON.stringify(currentUser));
        updateAuthUI();
        go('home');
        showToast(`Welcome back, ${currentUser.name}!`, 'success');
    }
    if (btn) { btn.disabled = false; btn.innerHTML = 'Sign In'; }
}

// ============================================================
// REGISTER
// ============================================================
async function doRegister() {
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const pass = document.getElementById('reg-pass').value;
    const confirm = document.getElementById('reg-confirm').value;
    const btn = document.getElementById('reg-btn');

    if (!name || !email || !pass) { alert('All fields are required'); return; }
    if (pass !== confirm) { alert('Passwords do not match'); return; }
    if (pass.length < 6) { alert('Password must be at least 6 characters'); return; }

    if (btn) { btn.disabled = true; btn.innerHTML = '<div class="spinner"></div> Creating account...'; }

    try {
        const response = await fetch(`${API}/register.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password: pass })
        });
        const data = await response.json();
        if (data.status === 'success') {
            currentUser = data.data;
            localStorage.setItem('cinehub_user', JSON.stringify(currentUser));
            updateAuthUI();
            go('home');
            showToast(`Account created! Welcome ${name}!`, 'success');
        } else {
            alert(data.message);
        }
    } catch (error) {
        // Fallback for demo
        currentUser = { id: Date.now(), name: name, email: email };
        localStorage.setItem('cinehub_user', JSON.stringify(currentUser));
        updateAuthUI();
        go('home');
        showToast(`Account created! Welcome ${name}!`, 'success');
    }
    if (btn) { btn.disabled = false; btn.innerHTML = 'Create Account'; }
}

// ============================================================
// LOGOUT
// ============================================================
function doLogout() {
    currentUser = null;
    localStorage.removeItem('cinehub_user');
    updateAuthUI();
    go('home');
    showToast('Logged out successfully', 'success');
}

// ============================================================
// EVENT LISTENERS
// ============================================================
function bindEvents() {
    // Navigation
    document.querySelectorAll('.nav-link[data-page]').forEach(el => {
        el.addEventListener('click', () => go(el.dataset.page));
    });

    // Dropdown items for movies
    document.querySelectorAll('.dropdown-item[data-type="movie"]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.stopPropagation();
            const genre = el.dataset.genre;
            go('movies');
            if (genre) {
                activeMovieGenre = genre;
                applyMovieFilters();
                document.querySelectorAll('#genre-chips .chip').forEach(c => {
                    c.classList.remove('active');
                    if (c.dataset.genre === genre) c.classList.add('active');
                });
            }
        });
    });

    // Dropdown items for TV shows
    document.querySelectorAll('.dropdown-item[data-type="tv"]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.stopPropagation();
            const genre = el.dataset.genre;
            go('tvshows');
            if (genre) {
                activeTVGenre = genre;
                applyTVFilters();
                document.querySelectorAll('#tv-genre-chips .chip').forEach(c => {
                    c.classList.remove('active');
                    if (c.dataset.tvGenre === genre) c.classList.add('active');
                });
            }
        });
    });

    const logo = document.getElementById('logo');
    if (logo) logo.addEventListener('click', () => go('home'));

    // Auth buttons
    const navSigninBtn = document.getElementById('nav-signin-btn');
    const navSignupBtn = document.getElementById('nav-signup-btn');
    const navSignoutBtn = document.getElementById('nav-signout-btn');

    if (navSigninBtn) navSigninBtn.addEventListener('click', () => go('signin'));
    if (navSignupBtn) navSignupBtn.addEventListener('click', () => go('register'));
    if (navSignoutBtn) navSignoutBtn.addEventListener('click', doLogout);

    // Search input
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            const activePage = document.querySelector('.page.active').id;
            if (activePage === 'page-movies') {
                handleMovieSearch(e);
            } else if (activePage === 'page-tvshows') {
                handleTVSearch(e);
            }
        });
    }

    const navAvatar = document.getElementById('nav-avatar');
    if (navAvatar) navAvatar.addEventListener('click', () => go('profile'));

    document.querySelectorAll('.see-all-link, .explore-link, .movies-link, .tvshows-link, .mylist-link, .home-link').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            if (el.classList.contains('movies-link') || el.classList.contains('see-all-link') || el.classList.contains('explore-link')) go('movies');
            else if (el.classList.contains('tvshows-link')) go('tvshows');
            else if (el.classList.contains('mylist-link')) go('mylist');
            else if (el.classList.contains('home-link')) go('home');
        });
    });

    const viewAllLink = document.querySelector('.view-all-link');
    if (viewAllLink) viewAllLink.addEventListener('click', (e) => { e.preventDefault(); go('mylist'); });

    // Movie genre chips
    document.querySelectorAll('#genre-chips .chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const genre = chip.dataset.genre || '';
            document.querySelectorAll('#genre-chips .chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            filterMoviesByGenre(genre);
        });
    });

    // Movie year checkboxes
    document.querySelectorAll('#page-movies .year-check').forEach(cb => {
        cb.addEventListener('change', () => filterMoviesByYear());
    });

    // Movie rating stars
    document.querySelectorAll('#rating-filter .star-filter').forEach(star => {
        star.addEventListener('click', function () {
            const rating = parseInt(this.dataset.rating);
            document.querySelectorAll('#rating-filter .star-filter').forEach((s, i) => {
                if (i < rating) s.classList.remove('empty');
                else s.classList.add('empty');
            });
            filterMoviesByRating(rating);
        });
    });

    // TV genre chips
    document.querySelectorAll('#tv-genre-chips .chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const genre = chip.dataset.tvGenre || '';
            document.querySelectorAll('#tv-genre-chips .chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            filterTVShowsByGenre(genre);
        });
    });

    // TV year checkboxes
    document.querySelectorAll('#page-tvshows .tv-year-check').forEach(cb => {
        cb.addEventListener('change', () => filterTVShowsByYear());
    });

    // TV rating stars
    document.querySelectorAll('#tv-rating-filter .star-filter').forEach(star => {
        star.addEventListener('click', function () {
            const rating = parseInt(this.dataset.tvRating);
            document.querySelectorAll('#tv-rating-filter .star-filter').forEach((s, i) => {
                if (i < rating) s.classList.remove('empty');
                else s.classList.add('empty');
            });
            filterTVShowsByRating(rating);
        });
    });

    const watchBtn = document.querySelector('.btn-primary[data-movie-id="m1"]');
    if (watchBtn) watchBtn.addEventListener('click', () => openDetail('m1'));

    // Card clicks
    document.body.addEventListener('click', (e) => {
        const posterCard = e.target.closest('.poster-card');
        if (posterCard && !e.target.closest('.oi-btn')) {
            const movieId = posterCard.dataset.movieId;
            const type = posterCard.dataset.type || 'movie';
            if (movieId) openDetail(movieId, type);
        }

        const playIcon = e.target.closest('.play-icon');
        if (playIcon) {
            const card = playIcon.closest('.poster-card');
            if (card && card.dataset.movieId) openDetail(card.dataset.movieId, card.dataset.type || 'movie');
        }

        // ✅ FIX 2: Handle favorite icon click — checks login first via toggleFavorite
        const favIcon = e.target.closest('.fav-icon');
        if (favIcon) {
            e.stopPropagation();
            const card = favIcon.closest('.poster-card');
            if (card && card.dataset.movieId) {
                toggleFavorite(card.dataset.movieId);
            }
        }

        const landCard = e.target.closest('.land-card');
        if (landCard && landCard.dataset.movieId) openDetail(landCard.dataset.movieId, landCard.dataset.type || 'movie');

        const continueItem = e.target.closest('.continue-item');
        if (continueItem && continueItem.dataset.movieId) openDetail(continueItem.dataset.movieId, continueItem.dataset.type || 'movie');

        const morePoster = e.target.closest('#detail-more .poster-card');
        if (morePoster && morePoster.dataset.movieId) openDetail(morePoster.dataset.movieId, morePoster.dataset.type || 'movie');
    });

    const favBtn = document.getElementById('fav-btn');
    if (favBtn) favBtn.addEventListener('click', () => {
        if (currentMovieId) toggleFavorite(currentMovieId);
    });

    const signinBtn = document.getElementById('signin-btn');
    if (signinBtn) signinBtn.addEventListener('click', doLogin);

    const regBtn = document.getElementById('reg-btn');
    if (regBtn) regBtn.addEventListener('click', doRegister);

    const switchToRegister = document.getElementById('switch-to-register');
    const switchToSignin = document.getElementById('switch-to-signin');
    if (switchToRegister) switchToRegister.addEventListener('click', () => go('register'));
    if (switchToSignin) switchToSignin.addEventListener('click', () => go('signin'));

    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', function () {
            const targetId = this.dataset.target;
            const input = document.getElementById(targetId);
            if (input) {
                if (input.type === 'password') {
                    input.type = 'text';
                    this.innerHTML = '<i class="fas fa-eye"></i>';
                } else {
                    input.type = 'password';
                    this.innerHTML = '<i class="fas fa-eye-slash"></i>';
                }
            }
        });
    });

    const profileContinueBtn = document.getElementById('profile-continue-btn');
    if (profileContinueBtn) profileContinueBtn.addEventListener('click', () => openDetail('m1'));

    const signoutItem = document.getElementById('signout-item');
    if (signoutItem) signoutItem.addEventListener('click', doLogout);

    document.querySelectorAll('.footer-link, .simple-footer-links a, .social-icon').forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.classList.contains('movies-link')) { e.preventDefault(); go('movies'); }
            else if (link.classList.contains('tvshows-link')) { e.preventDefault(); go('tvshows'); }
            else if (link.classList.contains('home-link')) { e.preventDefault(); go('home'); }
            else if (link.classList.contains('register-link')) { e.preventDefault(); go('register'); }
            else if (!link.classList.contains('footer-link')) e.preventDefault();
        });
    });

    window.addEventListener('scroll', () => {
        const nav = document.getElementById('main-nav');
        if (nav) nav.style.background = window.scrollY > 60 ? 'rgba(0,0,0,.97)' : 'linear-gradient(to bottom,rgba(0,0,0,.95),rgba(0,0,0,.7))';
    });

    document.querySelectorAll('img').forEach(fixImageError);
}

// ============================================================
// INIT
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
    bindEvents();
    updateAuthUI();
    go(window.location.hash.slice(1) || 'home');
});