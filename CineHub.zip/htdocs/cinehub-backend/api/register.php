<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents('php://input'), true);

$name = $data['name'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (empty($name) || empty($email) || empty($password)) {
    sendResponse('error', null, 'All fields are required');
}

if (strlen($password) < 6) {
    sendResponse('error', null, 'Password must be at least 6 characters');
}

// Check if email already exists
$checkQuery = "SELECT id FROM users WHERE email = :email";
$checkStmt = $db->prepare($checkQuery);
$checkStmt->bindValue(':email', $email);
$checkStmt->execute();

if ($checkStmt->rowCount() > 0) {
    sendResponse('error', null, 'Email already exists');
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$query = "INSERT INTO users (name, email, password) VALUES (:name, :email, :password)";
$stmt = $db->prepare($query);
$stmt->bindValue(':name', $name);
$stmt->bindValue(':email', $email);
$stmt->bindValue(':password', $hashedPassword);

if ($stmt->execute()) {
    $userId = $db->lastInsertId();
    sendResponse('success', ['id' => $userId, 'name' => $name, 'email' => $email], 'Registration successful');
} else {
    sendResponse('error', null, 'Registration failed');
}
?>