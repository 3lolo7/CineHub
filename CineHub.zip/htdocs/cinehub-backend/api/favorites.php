<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $userId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
        
        if (!$userId) {
            sendResponse('error', null, 'User ID is required');
        }
        
        $query = "SELECT f.*, 
                  CASE 
                      WHEN f.type = 'movie' THEN m.title 
                      WHEN f.type = 'tv' THEN t.title 
                  END as title,
                  CASE 
                      WHEN f.type = 'movie' THEN m.poster 
                      WHEN f.type = 'tv' THEN t.poster 
                  END as poster,
                  CASE 
                      WHEN f.type = 'movie' THEN m.rating 
                      WHEN f.type = 'tv' THEN t.rating 
                  END as rating
                  FROM favorites f
                  LEFT JOIN movies m ON f.movie_id = m.id AND f.type = 'movie'
                  LEFT JOIN tv_shows t ON f.movie_id = t.id AND f.type = 'tv'
                  WHERE f.user_id = :user_id";
        
        $stmt = $db->prepare($query);
        $stmt->bindValue(':user_id', $userId);
        $stmt->execute();
        $favorites = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse('success', $favorites);
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $userId = $data['user_id'] ?? 0;
        $movieId = $data['movie_id'] ?? '';
        $type = $data['type'] ?? 'movie';
        
        if (!$userId || empty($movieId)) {
            sendResponse('error', null, 'User ID and Movie ID are required');
        }
        
        // Check if already exists
        $checkQuery = "SELECT id FROM favorites WHERE user_id = :user_id AND movie_id = :movie_id";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindValue(':user_id', $userId);
        $checkStmt->bindValue(':movie_id', $movieId);
        $checkStmt->execute();
        
        if ($checkStmt->rowCount() > 0) {
            // Remove favorite
            $deleteQuery = "DELETE FROM favorites WHERE user_id = :user_id AND movie_id = :movie_id";
            $deleteStmt = $db->prepare($deleteQuery);
            $deleteStmt->bindValue(':user_id', $userId);
            $deleteStmt->bindValue(':movie_id', $movieId);
            $deleteStmt->execute();
            sendResponse('success', null, 'Removed from favorites');
        } else {
            // Add favorite
            $insertQuery = "INSERT INTO favorites (user_id, movie_id, type) VALUES (:user_id, :movie_id, :type)";
            $insertStmt = $db->prepare($insertQuery);
            $insertStmt->bindValue(':user_id', $userId);
            $insertStmt->bindValue(':movie_id', $movieId);
            $insertStmt->bindValue(':type', $type);
            $insertStmt->execute();
            sendResponse('success', null, 'Added to favorites');
        }
        break;
        
    default:
        sendResponse('error', null, 'Invalid request method');
}
?>