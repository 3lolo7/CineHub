<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $genre = isset($_GET['genre']) ? $_GET['genre'] : '';
        $year = isset($_GET['year']) ? $_GET['year'] : '';
        $rating = isset($_GET['rating']) ? (int)$_GET['rating'] : 0;
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        
        $query = "SELECT * FROM tv_shows WHERE 1=1";
        $params = [];
        
        if (!empty($genre)) {
            $query .= " AND category = :genre";
            $params[':genre'] = $genre;
        }
        
        if (!empty($year)) {
            $years = explode('-', $year);
            if (count($years) == 2) {
                $query .= " AND year BETWEEN :year_start AND :year_end";
                $params[':year_start'] = $years[0];
                $params[':year_end'] = $years[1];
            }
        }
        
        if ($rating > 0) {
            $query .= " AND rating >= :rating";
            $params[':rating'] = $rating;
        }
        
        if (!empty($search)) {
            $query .= " AND (title LIKE :search OR category LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        $query .= " ORDER BY year DESC";
        
        // تأكد أنه مافيش LIMIT 10 هنا
        
        $stmt = $db->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $tvshows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse('success', $tvshows);
        break;
        
    default:
        sendResponse('error', null, 'Invalid request method');
}
?>