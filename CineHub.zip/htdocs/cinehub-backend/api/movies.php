<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        // جلب الأفلام مع الفلاتر
        $genre = isset($_GET['genre']) ? $_GET['genre'] : '';
        $year = isset($_GET['year']) ? $_GET['year'] : '';
        $rating = isset($_GET['rating']) ? (int)$_GET['rating'] : 0;
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        
        $query = "SELECT * FROM movies WHERE 1=1";
        $params = [];
        
        if (!empty($genre)) {
            $query .= " AND category = :genre";
            $params[':genre'] = $genre;
        }
        
        if (!empty($year)) {
            $years = explode('-', $year);
            if (count($years) == 2) {
                $query .= " AND year BETWEEN :year_start AND :year_end";
                $params[':year_start'] = $years[0];
                $params[':year_end'] = $years[1];
            }
        }
        
        if ($rating > 0) {
            $query .= " AND rating >= :rating";
            $params[':rating'] = $rating;
        }
        
        if (!empty($search)) {
            $query .= " AND (title LIKE :search OR category LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        $query .= " ORDER BY year DESC";
        
        $stmt = $db->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        sendResponse('success', $movies);
        break;
        
    case 'POST':
        // إضافة فيلم جديد (للمشرفين فقط)
        $data = json_decode(file_get_contents('php://input'), true);
        
        $query = "INSERT INTO movies (id, title, rating, category, director, year, poster, backdrop, description) 
                  VALUES (:id, :title, :rating, :category, :director, :year, :poster, :backdrop, :description)";
        
        $stmt = $db->prepare($query);
        $stmt->bindValue(':id', $data['id']);
        $stmt->bindValue(':title', $data['title']);
        $stmt->bindValue(':rating', $data['rating']);
        $stmt->bindValue(':category', $data['category']);
        $stmt->bindValue(':director', $data['director']);
        $stmt->bindValue(':year', $data['year']);
        $stmt->bindValue(':poster', $data['poster']);
        $stmt->bindValue(':backdrop', $data['backdrop']);
        $stmt->bindValue(':description', $data['description']);
        
        if ($stmt->execute()) {
            sendResponse('success', null, 'Movie added successfully');
        } else {
            sendResponse('error', null, 'Failed to add movie');
        }
        break;
        
    default:
        sendResponse('error', null, 'Invalid request method');
}
?>