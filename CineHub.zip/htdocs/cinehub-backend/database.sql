-- ============================================================
-- إنشاء قاعدة البيانات
-- ============================================================
CREATE DATABASE IF NOT EXISTS cinehub_db;
USE cinehub_db;

-- جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول الأفلام (مع إضافة عمود cast)
CREATE TABLE IF NOT EXISTS movies (
    id VARCHAR(10) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    rating DECIMAL(3,1) NOT NULL,
    category VARCHAR(50) NOT NULL,
    director VARCHAR(100),
    year INT NOT NULL,
    poster TEXT,
    backdrop TEXT,
    description TEXT,
    cast TEXT DEFAULT NULL COMMENT 'JSON array of cast members'
);

-- جدول المسلسلات (مع إضافة عمود cast)
CREATE TABLE IF NOT EXISTS tv_shows (
    id VARCHAR(10) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    rating DECIMAL(3,1) NOT NULL,
    category VARCHAR(50) NOT NULL,
    director VARCHAR(100),
    year INT NOT NULL,
    seasons INT DEFAULT 1,
    episodes INT DEFAULT 0,
    poster TEXT,
    backdrop TEXT,
    description TEXT,
    cast TEXT DEFAULT NULL COMMENT 'JSON array of cast members'
);

-- جدول المفضلات
CREATE TABLE IF NOT EXISTS favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    movie_id VARCHAR(10) NOT NULL,
    type ENUM('movie', 'tv') DEFAULT 'movie',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_favorite (user_id, movie_id)
);

-- ============================================================
-- إدخال بيانات الأفلام (20 فيلم) مع الممثلين
-- ============================================================
INSERT INTO movies (id, title, rating, category, director, year, poster, backdrop, description, cast) VALUES
('m1', 'Interstellar', 8.6, 'Sci-Fi', 'Christopher Nolan', 2014, 'https://image.tmdb.org/t/p/w400/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg', 'https://image.tmdb.org/t/p/w1280/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg', 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.', '[{"name":"Matthew McConaughey","role":"Cooper"},{"name":"Anne Hathaway","role":"Brand"},{"name":"Jessica Chastain","role":"Murph"}]'),
('m2', 'Inception', 8.8, 'Sci-Fi', 'Christopher Nolan', 2010, 'https://image.tmdb.org/t/p/w400/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg', 'https://image.tmdb.org/t/p/w1280/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg', 'A thief who steals corporate secrets through dream-sharing technology is given the task of planting an idea into a CEO\'s mind.', '[{"name":"Leonardo DiCaprio","role":"Cobb"},{"name":"Joseph Gordon-Levitt","role":"Arthur"},{"name":"Elliot Page","role":"Ariadne"}]'),
('m3', 'The Dark Knight', 9.0, 'Action', 'Christopher Nolan', 2008, 'https://image.tmdb.org/t/p/w400/qJ2tW6WMUDux911r6m7haRef0WH.jpg', 'https://image.tmdb.org/t/p/w1280/qJ2tW6WMUDux911r6m7haRef0WH.jpg', 'When the Joker wreaks havoc on Gotham, Batman must accept one of the greatest psychological and physical tests.', '[{"name":"Christian Bale","role":"Bruce Wayne"},{"name":"Heath Ledger","role":"Joker"},{"name":"Aaron Eckhart","role":"Harvey Dent"}]'),
('m4', 'Oppenheimer', 8.3, 'Drama', 'Christopher Nolan', 2023, 'https://image.tmdb.org/t/p/w400/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg', 'https://image.tmdb.org/t/p/w1280/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg', 'The story of J. Robert Oppenheimer and his role in the development of the atomic bomb.', '[{"name":"Cillian Murphy","role":"Oppenheimer"},{"name":"Emily Blunt","role":"Kitty"},{"name":"Matt Damon","role":"Leslie Groves"}]'),
('m5', 'Dune: Part Two', 8.5, 'Sci-Fi', 'Denis Villeneuve', 2024, 'https://image.tmdb.org/t/p/w1280/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg', 'https://image.tmdb.org/t/p/w1280/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg', 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.', '[{"name":"Timothée Chalamet","role":"Paul"},{"name":"Zendaya","role":"Chani"},{"name":"Rebecca Ferguson","role":"Lady Jessica"}]'),
('m6', 'The Batman', 7.8, 'Action', 'Matt Reeves', 2022, 'https://image.tmdb.org/t/p/w1280/74xTEgt7R36Fpooo50r9T25onhq.jpg', 'https://image.tmdb.org/t/p/w1280/74xTEgt7R36Fpooo50r9T25onhq.jpg', 'Batman investigates corruption in Gotham while facing the Riddler.', '[{"name":"Robert Pattinson","role":"Batman"},{"name":"Zoë Kravitz","role":"Catwoman"},{"name":"Paul Dano","role":"Riddler"}]'),
('m7', 'Top Gun: Maverick', 8.3, 'Action', 'Joseph Kosinski', 2022, 'https://image.tmdb.org/t/p/w1280/n0YuM4f5lvGAP6MAW2kBIzugXnc.jpg', 'https://image.tmdb.org/t/p/w1280/n0YuM4f5lvGAP6MAW2kBIzugXnc.jpg', 'Maverick pushes the envelope as a test pilot and trains a new generation of Top Gun graduates.', '[{"name":"Tom Cruise","role":"Maverick"},{"name":"Miles Teller","role":"Rooster"},{"name":"Jennifer Connelly","role":"Penny"}]'),
('m8', 'Avatar: The Way of Water', 7.6, 'Sci-Fi', 'James Cameron', 2022, 'https://image.tmdb.org/t/p/w400/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg', 'https://image.tmdb.org/t/p/w1280/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg', 'Jake Sully lives with his family on Pandora when a familiar threat returns.', '[{"name":"Sam Worthington","role":"Jake"},{"name":"Zoe Saldana","role":"Neytiri"},{"name":"Sigourney Weaver","role":"Kiri"}]'),
('m9', 'Glass Onion', 7.1, 'Comedy', 'Rian Johnson', 2022, 'https://image.tmdb.org/t/p/w1280/vDGr1YdrlfbU9wxTOdpf3zChmv9.jpg', 'https://image.tmdb.org/t/p/w1280/vDGr1YdrlfbU9wxTOdpf3zChmv9.jpg', 'Benoit Blanc travels to Greece to solve a mystery surrounding a tech billionaire.', '[{"name":"Daniel Craig","role":"Benoit Blanc"},{"name":"Edward Norton","role":"Miles Bron"},{"name":"Janelle Monáe","role":"Andi"}]'),
('m10', 'Black Panther: Wakanda Forever', 6.8, 'Action', 'Ryan Coogler', 2022, 'https://image.tmdb.org/t/p/w1280/sv1xJUazXeYqALzczSZ3O6nkH75.jpg', 'https://image.tmdb.org/t/p/w1280/sv1xJUazXeYqALzczSZ3O6nkH75.jpg', 'The leaders of Wakanda fight to protect their nation from intervening world powers.', '[{"name":"Letitia Wright","role":"Shuri"},{"name":"Angela Bassett","role":"Ramonda"}]'),
('m11', 'The Whale', 7.7, 'Drama', 'Darren Aronofsky', 2022, 'https://image.tmdb.org/t/p/w400/jQ0gylJMxWSL490sy0RrPj1Lj7e.jpg', 'https://image.tmdb.org/t/p/w1280/jQ0gylJMxWSL490sy0RrPj1Lj7e.jpg', 'A reclusive English teacher attempts to reconnect with his estranged teenage daughter.', '[{"name":"Brendan Fraser","role":"Charlie"},{"name":"Sadie Sink","role":"Ellie"}]'),
('m12', 'Everything Everywhere All at Once', 7.8, 'Drama', 'Daniels', 2022, 'https://image.tmdb.org/t/p/w400/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg', 'https://image.tmdb.org/t/p/w1280/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg', 'An aging Chinese immigrant is swept up in an adventure where she alone can save the world.', '[{"name":"Michelle Yeoh","role":"Evelyn"},{"name":"Ke Huy Quan","role":"Waymond"}]'),
('m13', 'John Wick: Chapter 4', 7.9, 'Action', 'Chad Stahelski', 2023, 'https://image.tmdb.org/t/p/w400/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg', 'https://image.tmdb.org/t/p/w1280/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg', 'John Wick uncovers a path to defeating the High Table.', '[{"name":"Keanu Reeves","role":"John Wick"},{"name":"Donnie Yen","role":"Caine"}]'),
('m14', 'Spider-Man: Across the Spider-Verse', 8.7, 'Animation', 'Joaquim Dos Santos', 2023, 'https://image.tmdb.org/t/p/w400/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg', 'https://image.tmdb.org/t/p/w1280/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg', 'Miles Morales catapults across the multiverse.', '[{"name":"Shameik Moore","role":"Miles"},{"name":"Hailee Steinfeld","role":"Gwen"}]'),
('m15', 'Barbie', 7.0, 'Comedy', 'Greta Gerwig', 2023, 'https://image.tmdb.org/t/p/w400/iuFNMS8U5cb6xfzi51Dbkovj7vM.jpg', 'https://image.tmdb.org/t/p/w1280/iuFNMS8U5cb6xfzi51Dbkovj7vM.jpg', 'Barbie and Ken go on a journey of self-discovery.', '[{"name":"Margot Robbie","role":"Barbie"},{"name":"Ryan Gosling","role":"Ken"}]'),
('m16', 'Poor Things', 8.3, 'Drama', 'Yorgos Lanthimos', 2023, 'https://image.tmdb.org/t/p/w400/kCGlIMHnOm8JPXq3rXM6c5wMxcT.jpg', 'https://image.tmdb.org/t/p/w1280/kCGlIMHnOm8JPXq3rXM6c5wMxcT.jpg', 'Bella Baxter is brought back to life by an unorthodox scientist.', '[{"name":"Emma Stone","role":"Bella"},{"name":"Mark Ruffalo","role":"Duncan"}]'),
('m17', 'The Killer', 7.2, 'Thriller', 'David Fincher', 2023, 'https://image.tmdb.org/t/p/w1280/ipkcgvN7h3yZnbYowthloHLKsf4.jpg', 'https://image.tmdb.org/t/p/w1280/ipkcgvN7h3yZnbYowthloHLKsf4.jpg', 'A solitary assassin begins to crack after a fateful near-miss.', '[{"name":"Michael Fassbender","role":"The Killer"}]'),
('m18', 'Napoleon', 7.5, 'History', 'Ridley Scott', 2023, 'https://image.tmdb.org/t/p/w1280/7Mw5fkDwm1Pg4JLeUgP3SgoOsTJ.jpg', 'https://image.tmdb.org/t/p/w1280/7Mw5fkDwm1Pg4JLeUgP3SgoOsTJ.jpg', 'An epic look at the rise of Napoleon Bonaparte.', '[{"name":"Joaquin Phoenix","role":"Napoleon"},{"name":"Vanessa Kirby","role":"Joséphine"}]'),
('m19', 'The Hunger Games: The Ballad of Songbirds & Snakes', 7.6, 'Action', 'Francis Lawrence', 2023, 'https://image.tmdb.org/t/p/w400/mDfJG3LC3Dqb67AZ52x3Z0jU0uB.jpg', 'https://image.tmdb.org/t/p/w1280/mDfJG3LC3Dqb67AZ52x3Z0jU0uB.jpg', 'Coriolanus Snow mentors Lucy Gray Baird in the 10th Hunger Games.', '[{"name":"Tom Blyth","role":"Snow"},{"name":"Rachel Zegler","role":"Lucy Gray"}]'),
('m20', 'Fight Club', 8.8, 'Drama', 'David Fincher', 1999, 'https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg', 'https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg', 'An insomniac office worker and a soap maker form an underground fight club.', '[{"name":"Brad Pitt","role":"Tyler Durden"},{"name":"Edward Norton","role":"The Narrator"},{"name":"Helena Bonham Carter","role":"Marla"}]');

-- ============================================================
-- إدخال بيانات المسلسلات (20 مسلسل) مع الممثلين
-- ============================================================
INSERT INTO tv_shows (id, title, rating, category, director, year, seasons, episodes, poster, backdrop, description, cast) VALUES
('s101', 'Stranger Things', 8.7, 'Sci-Fi', 'The Duffer Brothers', 2016, 4, 34, 'https://image.tmdb.org/t/p/w1280/uOOtwVbSr4QDjAGIifLDwpb2Pdl.jpg', 'https://image.tmdb.org/t/p/w1280/uOOtwVbSr4QDjAGIifLDwpb2Pdl.jpg', 'A group of kids uncover supernatural mysteries in their small town.', '[{"name":"Millie Bobby Brown","role":"Eleven"},{"name":"Finn Wolfhard","role":"Mike"},{"name":"David Harbour","role":"Hopper"}]'),
('s102', 'The Last of Us', 8.9, 'Drama', 'Craig Mazin', 2023, 1, 9, 'https://image.tmdb.org/t/p/w1280/dmo6TYuuJgaYinXBPjrgG9mB5od.jpg', 'https://image.tmdb.org/t/p/w1280/dmo6TYuuJgaYinXBPjrgG9mB5od.jpg', 'A survivor takes a young girl across post-apocalyptic America.', '[{"name":"Pedro Pascal","role":"Joel"},{"name":"Bella Ramsey","role":"Ellie"}]'),
('s103', 'House of the Dragon', 8.5, 'Fantasy', 'Miguel Sapochnik', 2022, 2, 18, 'https://image.tmdb.org/t/p/w1280/7QMsOTMUswlwxJP0rTTZfmz2tX2.jpg', 'https://image.tmdb.org/t/p/w1280/7QMsOTMUswlwxJP0rTTZfmz2tX2.jpg', 'The reign of House Targaryen begins with this epic prequel.', '[{"name":"Emma D\'Arcy","role":"Rhaenyra"},{"name":"Matt Smith","role":"Daemon"},{"name":"Olivia Cooke","role":"Alicent"}]'),
('s104', 'The Witcher', 8.2, 'Fantasy', 'Lauren Schmidt', 2019, 3, 24, 'https://image.tmdb.org/t/p/w1280/AoGsDM02UVt0npBA8OvpDcZbaMi.jpg', 'https://image.tmdb.org/t/p/w1280/AoGsDM02UVt0npBA8OvpDcZbaMi.jpg', 'Geralt of Rivia struggles to find his place in a world where people are more wicked than beasts.', '[{"name":"Henry Cavill","role":"Geralt"},{"name":"Anya Chalotra","role":"Yennefer"},{"name":"Freya Allan","role":"Ciri"}]'),
('s105', 'Wednesday', 8.4, 'Comedy', 'Tim Burton', 2022, 1, 8, 'https://image.tmdb.org/t/p/w1280/9PFonBhy4cQy7Jz20NpMygczOkv.jpg', 'https://image.tmdb.org/t/p/w1280/9PFonBhy4cQy7Jz20NpMygczOkv.jpg', 'Wednesday Addams is sent to Nevermore Academy.', '[{"name":"Jenna Ortega","role":"Wednesday"},{"name":"Emma Myers","role":"Enid"},{"name":"Gwendoline Christie","role":"Weems"}]'),
('s106', 'The Mandalorian', 8.7, 'Sci-Fi', 'Jon Favreau', 2019, 3, 24, 'https://image.tmdb.org/t/p/w400/sWgBv7LV2PRoQgkxwlibdGXKz1S.jpg', 'https://image.tmdb.org/t/p/w1280/sWgBv7LV2PRoQgkxwlibdGXKz1S.jpg', 'A lone bounty hunter travels the galaxy with Grogu.', '[{"name":"Pedro Pascal","role":"Mando"},{"name":"Grogu","role":"Baby Yoda"}]'),
('s107', 'Succession', 8.9, 'Drama', 'Jesse Armstrong', 2018, 4, 39, 'https://image.tmdb.org/t/p/w1280/z0XiwdrCQ9yVIr4O0pxzaAYRxdW.jpg', 'https://image.tmdb.org/t/p/w1280/z0XiwdrCQ9yVIr4O0pxzaAYRxdW.jpg', 'The Roy family fights for control of a global media empire.', '[{"name":"Brian Cox","role":"Logan Roy"},{"name":"Jeremy Strong","role":"Kendall"},{"name":"Sarah Snook","role":"Shiv"}]'),
('s108', 'The Bear', 8.6, 'Drama', 'Christopher Storer', 2022, 2, 18, 'https://image.tmdb.org/t/p/w1280/eKfVzzEazSIjJMrw9ADa2x8ksLz.jpg', 'https://image.tmdb.org/t/p/w1280/eKfVzzEazSIjJMrw9ADa2x8ksLz.jpg', 'A young chef returns to Chicago to run his family sandwich shop.', '[{"name":"Jeremy Allen White","role":"Carmy"},{"name":"Ebon Moss-Bachrach","role":"Richie"}]'),
('s109', 'Dahmer - Monster', 7.9, 'Crime', 'Ryan Murphy', 2022, 1, 10, 'https://image.tmdb.org/t/p/w1280/f2PVrphK0u81ES256lw3oAZuF3x.jpg', 'https://image.tmdb.org/t/p/w1280/f2PVrphK0u81ES256lw3oAZuF3x.jpg', 'The story of Jeffrey Dahmer, one of America\'s most notorious serial killers.', '[{"name":"Evan Peters","role":"Dahmer"},{"name":"Richard Jenkins","role":"Lionel"}]'),
('s110', 'One Piece', 8.7, 'Action', 'Matt Owens', 2023, 1, 8, 'https://image.tmdb.org/t/p/w1280/blWCPEqDGLBuLB9u89CxP9ORQP4.jpg', 'https://image.tmdb.org/t/p/w1280/blWCPEqDGLBuLB9u89CxP9ORQP4.jpg', 'Monkey D. Luffy and his pirate crew explore a fantastical world.', '[{"name":"Iñaki Godoy","role":"Luffy"},{"name":"Mackenyu","role":"Zoro"},{"name":"Emily Rudd","role":"Nami"}]'),
('s111', 'The Boys', 8.7, 'Action', 'Eric Kripke', 2019, 4, 32, 'https://image.tmdb.org/t/p/w1280/in1R2dDc421JxsoRWaIIAqVI2KE.jpg', 'https://image.tmdb.org/t/p/w1280/in1R2dDc421JxsoRWaIIAqVI2KE.jpg', 'A group of vigilantes set out to take down corrupt superheroes.', '[{"name":"Karl Urban","role":"Butcher"},{"name":"Jack Quaid","role":"Hughie"},{"name":"Antony Starr","role":"Homelander"}]'),
('s112', 'Yellowstone', 8.7, 'Drama', 'Taylor Sheridan', 2018, 5, 47, 'https://image.tmdb.org/t/p/w1280/peNC0eyc3TQJa6x4TdKcBPNP4t0.jpg', 'https://image.tmdb.org/t/p/w1280/peNC0eyc3TQJa6x4TdKcBPNP4t0.jpg', 'The Dutton family fights to control the largest contiguous ranch.', '[{"name":"Kevin Costner","role":"John Dutton"},{"name":"Luke Grimes","role":"Kayce"},{"name":"Kelly Reilly","role":"Beth"}]'),
('s113', '11.22.63', 8.1, 'Sci-Fi', 'Kevin Macdonald', 2016, 1, 8, 'https://image.tmdb.org/t/p/w1280/vnixbjrSYKRbfu5CHH3mVtDiWvI.jpg', 'https://image.tmdb.org/t/p/w1280/vnixbjrSYKRbfu5CHH3mVtDiWvI.jpg', 'A teacher travels back in time to prevent JFK\'s assassination.', '[{"name":"James Franco","role":"Jake Epping"},{"name":"Sarah Gadon","role":"Sadie Dunhill"},{"name":"Chris Cooper","role":"Al Templeton"}]'),
('s114', 'The Crown', 8.6, 'History', 'Peter Morgan', 2016, 6, 60, 'https://image.tmdb.org/t/p/w1280/1DDE0Z2Y805rqfkEjPbZsMLyPwa.jpg', 'https://image.tmdb.org/t/p/w1280/1DDE0Z2Y805rqfkEjPbZsMLyPwa.jpg', 'A biographical drama about the reign of Queen Elizabeth II.', '[{"name":"Imelda Staunton","role":"Queen Elizabeth"},{"name":"Jonathan Pryce","role":"Prince Philip"}]'),
('s115', 'Squid Game', 8.0, 'Thriller', 'Hwang Dong-hyuk', 2021, 2, 9, 'https://image.tmdb.org/t/p/w1280/1QdXdRYfktUSONkl1oD5gc6Be0s.jpg', 'https://image.tmdb.org/t/p/w1280/1QdXdRYfktUSONkl1oD5gc6Be0s.jpg', 'Hundreds of cash-strapped players accept a strange invitation.', '[{"name":"Lee Jung-jae","role":"Gi-hun"},{"name":"Park Hae-soo","role":"Sang-woo"}]'),
('s116', 'Prison Break', 8.3, 'Action', 'Paul Scheuring', 2005, 5, 90, 'https://image.tmdb.org/t/p/w1280/ux7OfhhrXO4FzJtuew18ShiBLq7.jpg', 'https://image.tmdb.org/t/p/w1280/ux7OfhhrXO4FzJtuew18ShiBLq7.jpg', 'A structural engineer installs himself in a prison to help his brother escape.', '[{"name":"Wentworth Miller","role":"Michael Scofield"},{"name":"Dominic Purcell","role":"Lincoln Burrows"},{"name":"Sarah Wayne Callies","role":"Sara Tancredi"},{"name":"Robert Knepper","role":"T-Bag"}]'),
('s117', 'The White Lotus', 8.1, 'Comedy', 'Mike White', 2021, 2, 13, 'https://image.tmdb.org/t/p/w1280/gbSaK9v1CbcYH1ISgbM7XObD2dW.jpg', 'https://image.tmdb.org/t/p/w1280/gbSaK9v1CbcYH1ISgbM7XObD2dW.jpg', 'A social satire following guests and employees of a tropical resort.', '[{"name":"Jennifer Coolidge","role":"Tanya"},{"name":"Murray Bartlett","role":"Armand"}]'),
('s118', 'Abbott Elementary', 8.2, 'Comedy', 'Quinta Brunson', 2021, 3, 52, 'https://image.tmdb.org/t/p/w1280/nBe1e3JJEZ6veGrVXNF0fRoLu56.jpg', 'https://image.tmdb.org/t/p/w1280/nBe1e3JJEZ6veGrVXNF0fRoLu56.jpg', 'A mockumentary following a group of dedicated teachers.', '[{"name":"Quinta Brunson","role":"Janine"},{"name":"Tyler James Williams","role":"Gregory"}]'),
('s119', 'True Detective', 8.9, 'Crime', 'Nic Pizzolatto', 2014, 4, 30, 'https://image.tmdb.org/t/p/w1280/mV16EBXQ6kDWpj31P6BEhmzTTkd.jpg', 'https://image.tmdb.org/t/p/w1280/mV16EBXQ6kDWpj31P6BEhmzTTkd.jpg', 'Anthology crime drama following detectives as they investigate complex cases.', '[{"name":"Matthew McConaughey","role":"Rust"},{"name":"Woody Harrelson","role":"Marty"},{"name":"Jodie Foster","role":"Liz"}]'),
('s120', 'The Night Agent', 7.7, 'Thriller', 'Shawn Ryan', 2023, 1, 10, 'https://image.tmdb.org/t/p/w1280/4c5yUNcaff4W4aPrkXE6zr7papX.jpg', 'https://image.tmdb.org/t/p/w1280/4c5yUNcaff4W4aPrkXE6zr7papX.jpg', 'A low-level FBI agent working in the White House uncovers a Russian mole.', '[{"name":"Gabriel Basso","role":"Peter"},{"name":"Luciane Buchanan","role":"Rose"}]');